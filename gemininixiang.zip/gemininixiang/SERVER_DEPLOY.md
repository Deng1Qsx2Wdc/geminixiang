# 🚀 服务器从零部署完整教程

本教程将指导你从购买服务器开始，完整部署 Gemini API 服务。

## 📋 目录

- [第一步：购买和配置服务器](#第一步购买和配置服务器)
- [第二步：连接服务器](#第二步连接服务器)
- [第三步：系统环境准备](#第三步系统环境准备)
- [第四步：部署项目](#第四步部署项目)
- [第五步：配置防火墙](#第五步配置防火墙)
- [第六步：验证部署](#第六步验证部署)
- [第七步：配置 Cookie](#第七步配置-cookie)
- [常见问题](#常见问题)

---

## 第一步：购买和配置服务器

### 1.1 选择服务器提供商

推荐服务器提供商：
- **阿里云**：https://www.aliyun.com
- **腾讯云**：https://cloud.tencent.com
- **华为云**：https://www.huaweicloud.com
- **AWS**：https://aws.amazon.com
- **Vultr**：https://www.vultr.com
- **DigitalOcean**：https://www.digitalocean.com

### 1.2 选择服务器配置

**最低配置要求：**
- CPU: 1 核
- 内存: 1GB
- 硬盘: 20GB
- 带宽: 1Mbps

**推荐配置：**
- CPU: 2 核
- 内存: 2GB
- 硬盘: 40GB
- 带宽: 3Mbps

### 1.3 选择操作系统

**推荐：Ubuntu 22.04 LTS 或 Ubuntu 24.04 LTS**

选择系统时注意：
- ✅ 选择 **Ubuntu** 系统（最稳定）
- ✅ 选择 **64位** 版本
- ✅ 选择 **LTS**（长期支持版本）

### 1.4 配置安全组/防火墙规则

在购买服务器时，需要配置安全组规则，开放以下端口：

| 端口 | 协议 | 说明 |
|------|------|------|
| 22 | TCP | SSH 远程连接（必须） |
| 8001 | TCP | Gemini API 服务端口（必须） |

**配置方法（以阿里云为例）：**
1. 进入服务器控制台
2. 找到「安全组」设置
3. 添加入站规则：
   - 端口：`8001`
   - 协议：`TCP`
   - 授权对象：`0.0.0.0/0`（允许所有 IP 访问）

---

## 第二步：连接服务器

### 2.1 获取服务器信息

购买完成后，在控制台获取以下信息：
- **公网 IP 地址**：例如 `123.456.789.012`
- **SSH 端口**：通常是 `22`
- **root 密码**：或 SSH 密钥

### 2.2 使用 SSH 连接（Windows）

#### 方法一：使用 PowerShell（推荐）

1. 打开 PowerShell（以管理员身份运行）
2. 执行以下命令：

```powershell
# 替换为你的服务器 IP
ssh root@你的服务器IP

# 例如：
ssh root@123.456.789.012
```

3. 首次连接会提示确认，输入 `yes`
4. 输入 root 密码（输入时不会显示，直接输入后按回车）

#### 方法二：使用 Xshell

1. 下载 Xshell：https://www.netsarang.com/zh/xshell/
2. 打开 Xshell，点击「新建」
3. 配置连接：
   - 名称：随意，如「Gemini 服务器」
   - 协议：SSH
   - 主机：你的服务器 IP
   - 端口：22
4. 点击「连接」，输入用户名 `root` 和密码

#### 方法三：使用 PuTTY

1. 下载 PuTTY：https://www.putty.org/
2. 打开 PuTTY
3. 输入服务器 IP，端口 22
4. 点击「Open」，输入用户名和密码

### 2.3 使用 SSH 连接（Mac/Linux）

```bash
ssh root@你的服务器IP

# 例如：
ssh root@123.456.789.012
```

---

## 第三步：系统环境准备

### 3.1 更新系统

连接服务器后，首先更新系统：

```bash
# Ubuntu/Debian
apt update && apt upgrade -y

# CentOS/RHEL
yum update -y
```

### 3.2 安装 Python 3

检查 Python 是否已安装：

```bash
python3 --version
```

如果没有安装或版本过低（需要 Python 3.8+），执行：

```bash
# Ubuntu/Debian（注意：需要使用 sudo）
sudo apt update
sudo apt install python3 python3-pip python3-venv -y

# CentOS/RHEL
sudo yum install python3 python3-pip -y
```

**验证安装：**

```bash
# 检查 Python 版本
python3 --version

# 检查 pip 是否可用
python3 -m pip --version

# 如果 pip 命令不可用，使用 python3 -m pip
```

### 3.3 安装 Git（可选，如果从 GitHub 部署）

```bash
# Ubuntu/Debian
apt install git -y

# CentOS/RHEL
yum install git -y
```

### 3.4 安装 unzip（用于解压 zip 文件）

```bash
# Ubuntu/Debian
apt install unzip -y

# CentOS/RHEL
yum install unzip -y
```

---

## 第四步：部署项目

### 方式一：从 GitHub 部署（推荐）

#### 4.1 创建项目目录

```bash
mkdir -p /opt/gemini-api
cd /opt/gemini-api
```

#### 4.2 克隆项目

```bash
git clone https://github.com/erxiansheng/gemininixiang.git .
```

如果 GitHub 访问慢，可以使用镜像：

```bash
# 使用 GitHub 镜像
git clone https://ghproxy.com/https://github.com/erxiansheng/gemininixiang.git .
```

**验证项目文件是否已正确克隆：**

```bash
# 检查关键文件是否存在
ls -la

# 应该能看到以下文件：
# - server.py
# - requirements.txt
# - client.py
# - api.py
# 等等

# 如果文件不存在，检查是否克隆成功
ls -la | grep -E "(server.py|requirements.txt)"
```

**如果文件不存在，重新克隆：**

```bash
# 删除当前目录内容（如果有）
rm -rf * .git 2>/dev/null

# 重新克隆
git clone https://github.com/erxiansheng/gemininixiang.git .

# 或使用镜像
git clone https://ghproxy.com/https://github.com/erxiansheng/gemininixiang.git .
```

#### 4.3 创建虚拟环境

**在创建虚拟环境之前，确保项目文件已存在：**

```bash
# 检查 requirements.txt 是否存在
if [ ! -f "requirements.txt" ]; then
    echo "错误：未找到 requirements.txt 文件"
    echo "请确保已完成项目克隆（步骤 4.2）"
    exit 1
fi

# 检查 server.py 是否存在
if [ ! -f "server.py" ]; then
    echo "错误：未找到 server.py 文件"
    echo "请确保已完成项目克隆（步骤 4.2）"
    exit 1
fi
```

**首先确保已安装必要的 Python 工具：**

```bash
# 如果之前没有安装，先安装 Python 和 pip
sudo apt install python3 python3-pip python3-venv -y

# 检查 Python 版本（需要 Python 3.8+）
python3 --version

# 检查 pip 是否可用
python3 -m pip --version
```

**如果虚拟环境创建失败，先清理旧的虚拟环境：**

```bash
# 如果存在旧的虚拟环境，先删除
rm -rf venv
```

**创建虚拟环境：**

```bash
# 创建虚拟环境
python3 -m venv venv

# 如果创建失败，尝试使用完整路径
python3 -m venv /opt/gemini-api/venv

# 激活虚拟环境
source venv/bin/activate

# 验证虚拟环境已激活（命令提示符前应该显示 (venv)）
which python3
```

**如果激活失败，检查虚拟环境是否正确创建：**

```bash
# 检查虚拟环境目录是否存在
ls -la venv/bin/

# 如果 venv/bin/activate 不存在，重新创建虚拟环境
rm -rf venv
python3 -m venv venv
source venv/bin/activate
```

#### 4.4 安装依赖

**确保虚拟环境已激活（命令提示符前应显示 `(venv)`）：**

```bash
# 如果未激活，先激活
source venv/bin/activate

# 升级 pip（使用虚拟环境中的 pip）
pip install --upgrade pip

# 如果 pip 命令不可用，使用 python3 -m pip
python3 -m pip install --upgrade pip

# 安装项目依赖
pip install -r requirements.txt

# 或者使用
python3 -m pip install -r requirements.txt
```

**如果遇到权限问题：**

```bash
# 确保在虚拟环境中，不需要 sudo
# 如果提示权限错误，检查虚拟环境目录权限
ls -la venv/
chmod -R 755 venv/
```

### 方式二：从 zip 文件部署

#### 4.1 上传 zip 文件到服务器

**在本地电脑执行（Windows PowerShell）：**

```powershell
# 替换为你的服务器 IP 和 zip 文件路径
scp E:\gemininixiang.zip root@你的服务器IP:/tmp/gemininixiang.zip
```

**或者使用 FTP 工具（如 FileZilla、WinSCP）上传**

#### 4.2 解压并部署

**在服务器上执行：**

```bash
# 创建项目目录
mkdir -p /opt/gemini-api
cd /opt/gemini-api

# 如果 zip 文件存在，解压文件
if [ -f "/tmp/gemininixiang.zip" ]; then
    unzip /tmp/gemininixiang.zip -d /tmp/
    
    # 复制文件到项目目录（处理不同的解压目录名）
    if [ -d "/tmp/gemininixiang" ]; then
        cp -r /tmp/gemininixiang/* /opt/gemini-api/ 2>/dev/null
    elif [ -d "/tmp/gemininixiang-main" ]; then
        cp -r /tmp/gemininixiang-main/* /opt/gemini-api/ 2>/dev/null
    fi
    
    # 清理临时文件
    rm -rf /tmp/gemininixiang* /tmp/gemininixiang.zip
fi

# 如果项目文件在子目录中（例如 /opt/gemini-api/gemininixiang），需要移动到当前目录
if [ -d "gemininixiang" ] && [ ! -f "server.py" ]; then
    echo "检测到项目文件在子目录中，正在移动..."
    cp -r gemininixiang/* /opt/gemini-api/ 2>/dev/null
    cp -r gemininixiang/.* /opt/gemini-api/ 2>/dev/null
    # 可选：删除子目录（如果不需要保留）
    # rm -rf gemininixiang
fi

# 验证项目文件是否存在
if [ ! -f "server.py" ] || [ ! -f "requirements.txt" ]; then
    echo "错误：未找到项目文件（server.py 或 requirements.txt）"
    echo "请检查："
    echo "  1. zip 文件是否已上传到 /tmp/gemininixiang.zip"
    echo "  2. 或者使用 Git 克隆项目（方式一）"
    echo "  3. 或者手动上传项目文件"
    exit 1
fi

echo "项目文件已准备完成"
ls -la | grep -E "(server.py|requirements.txt)"

# 确保已安装必要的 Python 工具
sudo apt install python3 python3-pip python3-venv -y

# 如果存在旧的虚拟环境，先删除
rm -rf venv

# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
source venv/bin/activate

# 验证虚拟环境已激活（命令提示符前应该显示 (venv)）
which python3

# 升级 pip
pip install --upgrade pip

# 如果 pip 命令不可用，使用 python3 -m pip
python3 -m pip install --upgrade pip || pip install --upgrade pip

# 安装项目依赖
pip install -r requirements.txt || python3 -m pip install -r requirements.txt
```

### 4.5 创建系统服务

创建 systemd 服务文件，让服务在后台自动运行：

```bash
sudo tee /etc/systemd/system/gemini-api.service > /dev/null <<EOF
[Unit]
Description=Gemini OpenAI API Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/gemini-api
Environment="PATH=/opt/gemini-api/venv/bin"
ExecStart=/opt/gemini-api/venv/bin/python /opt/gemini-api/server.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
```

### 4.6 启动服务

```bash
# 重新加载 systemd
sudo systemctl daemon-reload

# 启用服务（开机自启）
sudo systemctl enable gemini-api

# 启动服务
sudo systemctl start gemini-api

# 检查服务状态
sudo systemctl status gemini-api
```

如果看到 `Active: active (running)`，说明服务已成功启动！

---

## 第五步：配置防火墙

### 5.1 Ubuntu/Debian (UFW)

```bash
# 允许 8001 端口
sudo ufw allow 8001/tcp

# 如果防火墙未启用，启用它
sudo ufw enable

# 查看防火墙状态
sudo ufw status
```

### 5.2 CentOS/RHEL (Firewalld)

```bash
# 允许 8001 端口
sudo firewall-cmd --add-port=8001/tcp --permanent

# 重新加载防火墙
sudo firewall-cmd --reload

# 查看开放的端口
sudo firewall-cmd --list-ports
```

### 5.3 云服务器安全组

**重要**：除了服务器防火墙，还需要在云服务器控制台配置安全组：

1. 登录云服务器控制台
2. 找到「安全组」或「防火墙」设置
3. 添加入站规则：
   - **端口范围**：`8001`
   - **协议**：`TCP`
   - **授权对象**：`0.0.0.0/0`（允许所有 IP 访问）
   - **描述**：Gemini API 服务

---

## 第六步：验证部署

### 6.1 检查服务状态

```bash
sudo systemctl status gemini-api
```

应该看到：
```
Active: active (running)
```

### 6.2 查看服务日志

```bash
# 查看最新日志
sudo journalctl -u gemini-api -n 50 --no-pager

# 实时查看日志
sudo journalctl -u gemini-api -f
```

### 6.3 测试本地访问

在服务器上执行：

```bash
curl http://localhost:8001/v1/models
```

应该返回 JSON 格式的模型列表。

### 6.4 测试外部访问

**在本地电脑浏览器访问：**

```
http://你的服务器IP:8001/admin
```

例如：`http://123.456.789.012:8001/admin`

如果能看到登录页面，说明部署成功！

### 6.5 获取服务器 IP

如果不知道服务器的公网 IP，可以在服务器上执行：

```bash
# 方法1：查看公网 IP
curl https://api.ipify.org

# 方法2：查看所有网络接口 IP
hostname -I

# 方法3：查看详细网络信息
ip addr show
```

---

## 第七步：配置 Cookie

### 7.1 访问后台配置页面

在浏览器打开：

```
http://你的服务器IP:8001/admin
```

### 7.2 登录

- **用户名**：`admin`
- **密码**：`admin123`

### 7.3 获取 Cookie

1. 打开新标签页，访问：https://gemini.google.com
2. 登录你的 Google 账号
3. 按 `F12` 打开开发者工具
4. 切换到「网络」（Network）标签
5. 在 Gemini 页面发送一条消息
6. 在网络请求中找到任意一个请求
7. 点击该请求，查看「请求头」（Headers）
8. 找到 `Cookie` 字段
9. 右键点击 Cookie 值 → **Copy all as Header String**（或复制完整 Cookie 字符串）

### 7.4 配置 Cookie

1. 回到后台配置页面
2. 将复制的 Cookie 粘贴到「完整 Cookie」输入框
3. 点击「保存配置」
4. 看到「配置已保存并验证成功」提示

### 7.5 测试 API

配置完成后，可以测试 API 是否正常工作：

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://你的服务器IP:8001/v1",
    api_key="sk-gemini"
)

response = client.chat.completions.create(
    model="gemini-3.0-flash",
    messages=[{"role": "user", "content": "你好"}]
)

print(response.choices[0].message.content)
```

---

## 常用管理命令

### 服务管理

```bash
# 查看服务状态
sudo systemctl status gemini-api

# 启动服务
sudo systemctl start gemini-api

# 停止服务
sudo systemctl stop gemini-api

# 重启服务
sudo systemctl restart gemini-api

# 查看服务日志
sudo journalctl -u gemini-api -f

# 查看最近 50 行日志
sudo journalctl -u gemini-api -n 50
```

### 更新代码

如果使用 Git 部署：

```bash
cd /opt/gemini-api
git pull
source venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart gemini-api
```

### 查看端口占用

```bash
# 查看 8001 端口是否被占用
sudo lsof -i :8001

# 或使用 netstat
sudo netstat -tulpn | grep 8001
```

---

## 常见问题

### Q1: 无法连接服务器？

**检查清单：**
1. ✅ 服务器是否已启动？
2. ✅ 安全组是否开放了 22 端口？
3. ✅ IP 地址是否正确？
4. ✅ 密码是否正确？

**解决方法：**
- 检查云服务器控制台，确认服务器状态为「运行中」
- 检查安全组规则，确保 22 端口已开放
- 尝试使用云服务器控制台的「远程连接」功能

### Q2: 服务启动失败？

**查看日志：**
```bash
sudo journalctl -u gemini-api -n 50
```

**常见原因：**
1. 端口被占用：`sudo lsof -i :8001`
2. Python 依赖未安装：重新执行 `pip install -r requirements.txt`
3. 配置文件错误：检查 `/opt/gemini-api/config_data.json`

### Q3: 找不到 requirements.txt 文件？

**错误现象：**
- `ERROR: Could not open requirements file: [Errno 2] No such file or directory: 'requirements.txt'`

**原因：**
项目文件还没有正确部署到服务器上，或者项目文件在子目录中。

**解决方法：**

```bash
# 1. 检查当前目录
pwd
# 应该显示 /opt/gemini-api

# 2. 检查目录内容
ls -la

# 3. 情况A：如果看到子目录（如 gemininixiang），项目文件在子目录中
if [ -d "gemininixiang" ]; then
    echo "检测到项目文件在子目录中，正在移动..."
    cp -r gemininixiang/* /opt/gemini-api/ 2>/dev/null
    cp -r gemininixiang/.* /opt/gemini-api/ 2>/dev/null
    # 验证文件是否已移动
    ls -la | grep -E "(server.py|requirements.txt)"
fi

# 4. 情况B：如果看不到 server.py 和 requirements.txt，需要重新部署
if [ ! -f "server.py" ] || [ ! -f "requirements.txt" ]; then
    echo "项目文件不存在，重新克隆..."
    cd /opt/gemini-api
    rm -rf * .git 2>/dev/null
    git clone https://github.com/erxiansheng/gemininixiang.git .
    
    # 如果 GitHub 访问慢，使用镜像
    # git clone https://ghproxy.com/https://github.com/erxiansheng/gemininixiang.git .
    
    # 验证文件是否存在
    ls -la | grep -E "(server.py|requirements.txt)"
fi

# 5. 如果文件存在，继续后续步骤
```

### Q4: 虚拟环境创建失败或 pip 命令找不到？

**错误现象：**
- `Failing command: /opt/gemini-api/venv/bin/python3`
- `-bash: venv/bin/activate: No such file or directory`
- `Command 'pip' not found`

**解决方法：**

```bash
# 1. 确保已安装 Python 和 pip（使用 sudo）
sudo apt update
sudo apt install python3 python3-pip python3-venv -y

# 2. 检查 Python 版本
python3 --version

# 3. 检查 pip 是否可用
python3 -m pip --version

# 4. 进入项目目录
cd /opt/gemini-api

# 5. 删除旧的虚拟环境（如果存在）
rm -rf venv

# 6. 重新创建虚拟环境
python3 -m venv venv

# 7. 激活虚拟环境
source venv/bin/activate

# 8. 验证虚拟环境已激活（应该显示 (venv)）
which python3

# 9. 如果 pip 命令不可用，使用 python3 -m pip
python3 -m pip install --upgrade pip

# 10. 安装依赖
python3 -m pip install -r requirements.txt
```

**如果仍然失败，检查权限：**

```bash
# 检查目录权限
ls -la /opt/gemini-api/

# 修复权限（如果需要）
sudo chown -R root:root /opt/gemini-api/
chmod -R 755 /opt/gemini-api/
```

### Q5: 无法从外部访问？

**检查清单：**
1. ✅ 服务器防火墙是否开放 8001 端口？
2. ✅ 云服务器安全组是否开放 8001 端口？
3. ✅ 服务是否正常运行？
4. ✅ IP 地址是否正确？

**解决方法：**
```bash
# 检查服务状态
sudo systemctl status gemini-api

# 检查端口监听
sudo lsof -i :8001

# 检查防火墙
sudo ufw status  # Ubuntu
sudo firewall-cmd --list-ports  # CentOS
```

### Q6: Cookie 配置失败？

**可能原因：**
1. Cookie 已过期：重新获取 Cookie
2. Cookie 不完整：确保复制了完整的 Cookie 字符串
3. 网络问题：检查服务器是否能访问 gemini.google.com

**解决方法：**
1. 重新登录 gemini.google.com
2. 重新获取 Cookie（确保复制完整）
3. 检查服务器网络：`curl https://gemini.google.com`

### Q7: 如何修改端口？

编辑 `/opt/gemini-api/server.py`，找到：

```python
PORT = 8001
```

改为其他端口，例如：

```python
PORT = 8080
```

然后：
1. 重启服务：`sudo systemctl restart gemini-api`
2. 更新防火墙规则
3. 更新安全组规则

### Q8: 如何修改后台账号密码？

编辑 `/opt/gemini-api/server.py`，找到：

```python
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"
```

修改为你想要的用户名和密码，然后重启服务。

### Q9: 服务占用内存过高？

可以限制服务的内存使用，编辑服务文件：

```bash
sudo nano /etc/systemd/system/gemini-api.service
```

在 `[Service]` 部分添加：

```ini
MemoryLimit=512M
```

然后：
```bash
sudo systemctl daemon-reload
sudo systemctl restart gemini-api
```

### Q10: 如何备份配置？

```bash
# 备份配置文件
cp /opt/gemini-api/config_data.json /opt/gemini-api/config_data.json.backup

# 恢复配置
cp /opt/gemini-api/config_data.json.backup /opt/gemini-api/config_data.json
sudo systemctl restart gemini-api
```

---

## 🎉 部署完成！

恭喜！你已经成功部署了 Gemini API 服务。

### 访问地址

- **后台配置**：`http://你的服务器IP:8001/admin`
- **API 地址**：`http://你的服务器IP:8001/v1`
- **API Key**：`sk-gemini`

### 下一步

1. ✅ 访问后台配置页面
2. ✅ 配置 Cookie
3. ✅ 测试 API 调用
4. ✅ 开始使用！

### 获取帮助

如果遇到问题：
1. 查看服务日志：`sudo journalctl -u gemini-api -f`
2. 检查服务状态：`sudo systemctl status gemini-api`
3. 查看本文档的「常见问题」部分

---

**祝使用愉快！** 🚀

